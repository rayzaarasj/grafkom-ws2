Worksheet 2
by plus-satu [Bram Sedana W. - 1606824502] and [Rayza Arasj M. - 1606876052]

Hand.js/.html

This is a hand made by 11 Cubes and 10 Joints.
It has 12 Angle that can be changed, 10 Joints, and Hand in Y axis and Z axis.
Toggle animate will save non-animation state and return to it later when clicked again.
Animation state will always be saved, so that it will start from where it stoped.
